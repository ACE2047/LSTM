import os
from data_analysis import load_and_analyze_data, plot_data_distributions, plot_correlation_matrix, analyze_revenue_patterns, generate_summary_report
from lstm_model import train_lstm_model

def main():
    # Define the data path
    data_path = 'data/online_shoppers_intention.csv'
    
    # Check if file exists
    if not os.path.exists(data_path):
        print(f"Error: Could not find the dataset at {data_path}")
        print("Please ensure the file 'online_shoppers_intention.csv' is in the data directory.")
        return
    
    try:
        # Step 1: Perform data analysis
        print("Starting data analysis...")
        df = load_and_analyze_data(data_path)
        plot_data_distributions(df)
        plot_correlation_matrix(df)
        analyze_revenue_patterns(df)
        generate_summary_report(df)
        
        # Step 2: Train and evaluate LSTM model
        print("\nStarting LSTM model training...")
        model = train_lstm_model(data_path)
        
        print("\nProject execution completed successfully.")
        
    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("Please check that the file path is correct and the file exists.")
    except Exception as e:
        print(f"An error occurred during execution: {e}")

if __name__ == '__main__':
    main()