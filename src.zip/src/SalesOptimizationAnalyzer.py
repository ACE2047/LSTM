import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import datetime as dt

class SalesOptimizationAnalyzer:
    def __init__(self, df):
        self.df = df.copy()
        self.scaler = StandardScaler()
        
    def analyze_weekday_opportunities(self):
        """Analyze weekday patterns to identify improvement opportunities"""
        weekday_data = self.df[self.df['Weekend'] == 0]
        
        # Analyze peak conversion times
        weekday_conversion = weekday_data.groupby('Month')['Revenue'].mean()
        low_conversion_months = weekday_conversion[weekday_conversion < weekday_conversion.mean()]
        
        # Analyze visitor engagement patterns
        engagement_metrics = {
            'avg_duration': weekday_data['ProductRelated_Duration'].mean(),
            'bounce_rate': weekday_data['BounceRates'].mean(),
            'exit_rate': weekday_data['ExitRates'].mean(),
            'page_value': weekday_data['PageValues'].mean()
        }
        
        # Analyze traffic sources
        traffic_conversion = weekday_data.groupby('TrafficType')['Revenue'].agg(['count', 'mean'])
        traffic_conversion['conversion_rate'] = traffic_conversion['mean'] * 100
        
        return {
            'low_conversion_months': low_conversion_months,
            'engagement_metrics': engagement_metrics,
            'traffic_performance': traffic_conversion
        }
    
    def analyze_customer_acquisition(self):
        """Analyze patterns related to new customer acquisition"""
        new_visitors = self.df[self.df['VisitorType'] == 'New_Visitor']
        
        # Analyze when new visitors are most likely to convert
        conversion_by_period = new_visitors.groupby(['Weekend', 'Month'])['Revenue'].mean()
        
        # Analyze which traffic sources bring valuable new customers
        traffic_quality = new_visitors.groupby('TrafficType').agg({
            'Revenue': ['count', 'mean'],
            'PageValues': 'mean',
            'ProductRelated': 'mean'
        })
        
        # Identify successful conversion patterns
        converted_new = new_visitors[new_visitors['Revenue'] == 1]
        success_patterns = {
            'avg_pages_viewed': converted_new['ProductRelated'].mean(),
            'avg_duration': converted_new['ProductRelated_Duration'].mean(),
            'top_months': converted_new['Month'].mode().tolist(),
            'avg_special_day_value': converted_new['SpecialDay'].mean()
        }
        
        return {
            'conversion_timing': conversion_by_period,
            'traffic_quality': traffic_quality,
            'success_patterns': success_patterns
        }
    
    def generate_recommendations(self):
        """Generate specific recommendations based on data analysis"""
        weekday_analysis = self.analyze_weekday_opportunities()
        acquisition_analysis = self.analyze_customer_acquisition()
        
        recommendations = {
            'weekday_optimization': [],
            'customer_acquisition': [],
            'retention_strategies': []
        }
        
        # Weekday Optimization Recommendations
        low_months = weekday_analysis['low_conversion_months']
        if not low_months.empty:
            recommendations['weekday_optimization'].append({
                'focus': 'Seasonal Optimization',
                'finding': f"Lower conversion rates in months: {', '.join(low_months.index.astype(str))}",
                'action': "Implement targeted promotions during low-conversion months",
                'expected_impact': "Potential conversion rate increase of "
                                 f"{((weekday_analysis['engagement_metrics']['bounce_rate']) * 100):.1f}%"
            })
        
        # Traffic Source Optimization
        traffic_perf = weekday_analysis['traffic_performance']
        best_sources = traffic_perf[traffic_perf['conversion_rate'] > traffic_perf['conversion_rate'].mean()]
        recommendations['weekday_optimization'].append({
            'focus': 'Traffic Source Optimization',
            'finding': f"High-performing traffic sources identified: {len(best_sources)} channels",
            'action': "Increase investment in top-performing traffic sources",
            'expected_impact': "Potential conversion rate improvement of "
                             f"{(best_sources['conversion_rate'].mean() - traffic_perf['conversion_rate'].mean()):.1f}%"
        })
        
        # New Customer Acquisition Strategies
        acquisition_patterns = acquisition_analysis['success_patterns']
        recommendations['customer_acquisition'].append({
            'focus': 'New Visitor Engagement',
            'finding': f"Optimal engagement duration: {acquisition_patterns['avg_duration']:.1f} seconds",
            'action': "Optimize landing pages for first-time visitors",
            'expected_impact': "Potential new customer conversion increase based on "
                             f"{acquisition_patterns['avg_pages_viewed']:.1f} product page views"
        })
        
        # Retention Strategies
        returning_visitors = self.df[self.df['VisitorType'] == 'Returning_Visitor']
        retention_rate = len(returning_visitors) / len(self.df) * 100
        recommendations['retention_strategies'].append({
            'focus': 'Customer Retention',
            'finding': f"Current retention rate: {retention_rate:.1f}%",
            'action': "Implement personalized return visitor promotions",
            'expected_impact': "Target retention rate increase to "
                             f"{min(retention_rate * 1.2, 100):.1f}%"
        })
        
        return recommendations

def main():
    # Load and prepare data
    try:
        df = pd.read_csv('data/online_shoppers_intention.csv')
        
        # Initialize analyzer
        analyzer = SalesOptimizationAnalyzer(df)
        recommendations = analyzer.generate_recommendations()
        
        # Display recommendations
        print("\nE-commerce Optimization Recommendations")
        print("=" * 50)
        
        # Weekday Performance Optimization
        print("\n1. Weekday Performance Optimization:")
        print("-" * 40)
        for rec in recommendations['weekday_optimization']:
            print(f"\nFocus Area: {rec['focus']}")
            print(f"Finding: {rec['finding']}")
            print(f"Recommended Action: {rec['action']}")
            print(f"Expected Impact: {rec['expected_impact']}")
        
        # Customer Acquisition Strategies
        print("\n2. Customer Acquisition Strategies:")
        print("-" * 40)
        for rec in recommendations['customer_acquisition']:
            print(f"\nFocus Area: {rec['focus']}")
            print(f"Finding: {rec['finding']}")
            print(f"Recommended Action: {rec['action']}")
            print(f"Expected Impact: {rec['expected_impact']}")
        
        # Retention Strategies
        print("\n3. Customer Retention Strategies:")
        print("-" * 40)
        for rec in recommendations['retention_strategies']:
            print(f"\nFocus Area: {rec['focus']}")
            print(f"Finding: {rec['finding']}")
            print(f"Recommended Action: {rec['action']}")
            print(f"Expected Impact: {rec['expected_impact']}")
            
    except Exception as e:
        print(f"An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()