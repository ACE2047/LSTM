import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, classification_report
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Dropout, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping
import tensorflow as tf

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

# 1. Load the dataset with a more robust path handling
# Try multiple possible locations for the file
possible_paths = [
    'online_shoppers_intention.csv',
    'data/online_shoppers_intention.csv',
    '../data/online_shoppers_intention.csv',
    os.path.join(os.path.dirname(__file__), 'data', 'online_shoppers_intention.csv'),
    os.path.join(os.path.dirname(__file__), '..', 'data', 'online_shoppers_intention.csv')
]

df = None
for path in possible_paths:
    try:
        print(f"Trying to load from: {path}")
        df = pd.read_csv(path)
        print(f"Successfully loaded data from: {path}")
        break
    except FileNotFoundError:
        continue

if df is None:
    raise FileNotFoundError("Could not find the dataset file. Please ensure 'online_shoppers_intention.csv' is in the correct location and try again.")

# 2. Exploratory Data Analysis
print("Dataset shape:", df.shape)
print("\nColumns in the dataset:", df.columns.tolist())
print("\nData types:")
print(df.dtypes)
print("\nMissing values:")
print(df.isnull().sum())
print("\nSummary statistics for numerical features:")
print(df.describe())

# Check class distribution
print("\nTarget variable distribution:")
print(df['Revenue'].value_counts(normalize=True) * 100)

# 3. Data Preprocessing
# 3.1 Handle missing values (if any)
# If there are missing values, you might need to impute them
# For example: df.fillna(df.mean(), inplace=True)

# First, examine data types and convert non-numeric columns appropriately
for col in df.columns:
    if df[col].dtype == 'object':
        print(f"Column {col} has object type with values: {df[col].unique()}")

# 3.2 Encode categorical variables
categorical_features = ['VisitorType', 'Month', 'Weekend']
numerical_features = ['BounceRates', 'ExitRates', 'PageValues', 'ProductRelated', 
                      'Administrative', 'Administrative_Duration', 'Informational',
                      'Informational_Duration', 'ProductRelated_Duration', 'SpecialDay']

# Create a copy of the dataframe to avoid modifying the original
df_processed = df.copy()

# Ensure all features are in the correct data type
for col in numerical_features:
    df_processed[col] = pd.to_numeric(df_processed[col], errors='coerce')
    
    # Fill any NaN values that might have been created
    if df_processed[col].isnull().sum() > 0:
        print(f"Fixed {df_processed[col].isnull().sum()} NaN values in {col}")
        df_processed[col].fillna(df_processed[col].mean(), inplace=True)

# Ensure Revenue is numeric
df_processed['Revenue'] = pd.to_numeric(df_processed['Revenue'], errors='coerce')
if df_processed['Revenue'].isnull().sum() > 0:
    print(f"Fixed {df_processed['Revenue'].isnull().sum()} NaN values in Revenue")
    # For binary target, we'll replace NaNs with the most common value
    df_processed['Revenue'].fillna(df_processed['Revenue'].mode()[0], inplace=True)

# One-hot encode categorical variables
df_encoded = pd.get_dummies(df_processed, columns=categorical_features, drop_first=True)

# 3.3 Feature scaling
scaler = StandardScaler()
df_encoded[numerical_features] = scaler.fit_transform(df_encoded[numerical_features])

# 3.4 Split into features and target
X = df_encoded.drop('Revenue', axis=1)
y = df_encoded['Revenue']

# Check for any remaining object dtypes
print("\nChecking for object dtypes in prepared data:")
print(X.dtypes.value_counts())

# Convert everything to float32 for TensorFlow compatibility
X = X.astype('float32')
y = y.astype('float32')

# 3.5 Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 3.6 Reshape input data for LSTM (LSTM expects 3D input: [samples, time steps, features])
# For this use case, we'll treat each feature as a time step
X_train_lstm = X_train.values.reshape(X_train.shape[0], 1, X_train.shape[1])
X_test_lstm = X_test.values.reshape(X_test.shape[0], 1, X_test.shape[1])

print("LSTM input shape:", X_train_lstm.shape)
print("LSTM input dtype:", X_train_lstm.dtype)

# 4. Build LSTM Model
model = Sequential()

# First LSTM layer
model.add(LSTM(128, activation='relu', return_sequences=True, 
              input_shape=(X_train_lstm.shape[1], X_train_lstm.shape[2])))
model.add(BatchNormalization())
model.add(Dropout(0.2))

# Second LSTM layer
model.add(LSTM(64, activation='relu'))
model.add(BatchNormalization())
model.add(Dropout(0.2))

# Dense hidden layer
model.add(Dense(32, activation='relu'))
model.add(BatchNormalization())
model.add(Dropout(0.2))

# Output layer
model.add(Dense(1, activation='sigmoid'))

# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Model summary
model.summary()

# 5. Train the Model
# Define early stopping
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True, verbose=1)

# Train the model
history = model.fit(
    X_train_lstm, y_train,
    epochs=50,
    batch_size=32,
    validation_split=0.2,
    callbacks=[early_stopping],
    verbose=1
)

# 6. Model Evaluation
# 6.1 Plot training history
plt.figure(figsize=(12, 4))

# Plot training & validation accuracy values
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Train', 'Validation'], loc='upper left')

# Plot training & validation loss values
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Train', 'Validation'], loc='upper left')

plt.tight_layout()
plt.savefig('training_history.png')
plt.close()

# 6.2 Evaluate model performance on test set
y_pred_prob = model.predict(X_test_lstm).flatten()
y_pred = (y_pred_prob > 0.5).astype(int)

# Calculate metrics
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_pred_prob)

print("\nModel Performance Metrics:")
print(f"Accuracy: {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f"F1 Score: {f1:.4f}")
print(f"ROC AUC: {roc_auc:.4f}")

# Print classification report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Plot confusion matrix
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.title('Confusion Matrix')
plt.ylabel('Actual Label')
plt.xlabel('Predicted Label')
plt.savefig('confusion_matrix.png')
plt.close()

# 7. Feature Importance Analysis (Permutation Importance)
from sklearn.inspection import permutation_importance

# Reshape test data for direct model.predict use
def reshape_for_lstm(X):
    return X.reshape(X.shape[0], 1, X.shape[1])

# We need to define a scoring function for the LSTM model
def lstm_score(model, X, y):
    X_reshaped = reshape_for_lstm(X)
    y_pred = model.predict(X_reshaped)
    return roc_auc_score(y, y_pred)

# Perform permutation importance
X_test_array = X_test.values
r = permutation_importance(
    estimator=lambda X, y: lstm_score(model, X, y),
    X=X_test_array,
    y=y_test,
    n_repeats=5,  # Reduced from 10 to save time
    random_state=42,
    scoring='roc_auc'
)

# Get feature importance scores
feature_importance = pd.DataFrame({
    'Feature': X_test.columns,
    'Importance': r.importances_mean
})
feature_importance = feature_importance.sort_values('Importance', ascending=False)

# Plot feature importances
plt.figure(figsize=(12, 8))
sns.barplot(x='Importance', y='Feature', data=feature_importance.head(15))
plt.title('Feature Importance (Top 15)')
plt.tight_layout()
plt.savefig('feature_importance.png')
plt.close()

# 8. Save the model
model.save('ecommerce_lstm_model.h5')

# 9. Function for making predictions on new data
def predict_purchase_likelihood(new_data, model, scaler, categorical_features, numerical_features):
    """
    Predict purchase likelihood for new customer data.
    
    Parameters:
    new_data (DataFrame): New customer data
    model: Trained LSTM model
    scaler: Fitted scaler for numerical features
    categorical_features: List of categorical feature names
    numerical_features: List of numerical feature names
    
    Returns:
    Array of purchase probabilities
    """
    # Preprocess new data (similar to training data preprocessing)
    new_data_processed = new_data.copy()
    
    # Convert numerical columns to proper type
    for col in numerical_features:
        if col in new_data_processed.columns:
            new_data_processed[col] = pd.to_numeric(new_data_processed[col], errors='coerce')
            if new_data_processed[col].isnull().sum() > 0:
                new_data_processed[col].fillna(new_data_processed[col].mean(), inplace=True)
    
    # One-hot encode categorical variables
    new_data_encoded = pd.get_dummies(new_data_processed, columns=categorical_features, drop_first=True)
    
    # Ensure new_data_encoded has the same columns as training data
    missing_cols = set(X.columns) - set(new_data_encoded.columns)
    for col in missing_cols:
        new_data_encoded[col] = 0
    
    # Ensure columns are in the same order
    new_data_encoded = new_data_encoded[X.columns]
    
    # Scale numerical features
    new_data_encoded[numerical_features] = scaler.transform(new_data_encoded[numerical_features])
    
    # Convert to float32
    new_data_encoded = new_data_encoded.astype('float32')
    
    # Reshape for LSTM
    new_data_lstm = new_data_encoded.values.reshape(new_data_encoded.shape[0], 1, new_data_encoded.shape[1])
    
    # Make predictions
    purchase_probs = model.predict(new_data_lstm).flatten()
    
    return purchase_probs

print("\nModel saved and ready for predictions on new data.")
print("Use the predict_purchase_likelihood function for making predictions.")