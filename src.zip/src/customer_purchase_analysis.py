import pandas as pd
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt
import os

def preprocess_data(df):
    """Preprocess the data by encoding categorical variables and handling string values"""
    df = df.copy()
    
    # Encode Month column
    month_encoder = LabelEncoder()
    df['Month'] = month_encoder.fit_transform(df['Month'])
    
    # Encode VisitorType
    visitor_encoder = LabelEncoder()
    df['VisitorType'] = visitor_encoder.fit_transform(df['VisitorType'])
    
    # Convert Weekend boolean to int
    df['Weekend'] = df['Weekend'].astype(int)
    
    # Categorize SpecialDay influence
    df['SalesPeriod'] = pd.cut(df['SpecialDay'], 
                              bins=[-np.inf, 0, 0.2, 0.6, 1.0],
                              labels=['Regular Day', 'Minor Sale', 'Medium Sale', 'Major Sale'])
    
    return df, month_encoder, visitor_encoder

def analyze_customer_segments(df, visitor_encoder):
    """Analyze purchase patterns for different customer types, split by weekend/weekday"""
    df_analysis = df.copy()
    df_analysis['VisitorType'] = visitor_encoder.inverse_transform(df_analysis['VisitorType'])
    
    segments = []
    for is_weekend in [0, 1]:
        segment_data = df_analysis[df_analysis['Weekend'] == is_weekend]
        
        # Calculate metrics for this time segment
        visitor_stats = segment_data.groupby(['VisitorType', 'SalesPeriod'])['Revenue'].agg([
            'count',
            'mean',
            'sum'
        ]).round(3)
        
        visitor_stats['conversion_rate'] = (visitor_stats['mean'] * 100).round(2)
        visitor_stats['time_period'] = 'Weekend' if is_weekend else 'Weekday'
        
        segments.append(visitor_stats.reset_index())
    
    return pd.concat(segments)

def create_customer_specific_features(df):
    """Create features specific to customer purchase behavior"""
    # Time-based features
    df['TotalTime'] = df['Administrative_Duration'] + df['Informational_Duration'] + df['ProductRelated_Duration']
    df['AvgTimePerPage'] = df['TotalTime'] / (df['Administrative'] + df['Informational'] + df['ProductRelated']).clip(lower=1)
    df['BrowsingEfficiency'] = df['PageValues'] / df['TotalTime'].clip(lower=0.1)
    
    # Engagement features
    df['TotalPages'] = df['Administrative'] + df['Informational'] + df['ProductRelated']
    df['ProductFocus'] = df['ProductRelated'] / df['TotalPages'].clip(lower=1)
    
    # Combine bounce and exit rates
    df['BounceExitRisk'] = (df['BounceRates'] + df['ExitRates']) / 2
    
    return df

def analyze_purchase_conditions(df, visitor_encoder):
    """Analyze specific conditions that lead to purchases, split by weekend/weekday and special days"""
    purchase_conditions = {}
    
    df_analysis = df.copy()
    df_analysis['VisitorType'] = visitor_encoder.inverse_transform(df_analysis['VisitorType'])
    
    for visitor_type in df_analysis['VisitorType'].unique():
        customer_df = df_analysis[df_analysis['VisitorType'] == visitor_type]
        
        # Analyze weekday vs weekend separately
        time_periods = {
            'Weekday': customer_df[customer_df['Weekend'] == 0],
            'Weekend': customer_df[customer_df['Weekend'] == 1]
        }
        
        period_conditions = {}
        for period_name, period_df in time_periods.items():
            sales_conditions = {}
            
            # Analyze each sales period
            for sales_period in period_df['SalesPeriod'].unique():
                sales_df = period_df[period_df['SalesPeriod'] == sales_period]
                purchases = sales_df[sales_df['Revenue'] == 1]
                
                # Skip if no purchases in this period
                if len(purchases) == 0:
                    continue
                
                conditions = {
                    'total_visits': len(sales_df),
                    'successful_purchases': len(purchases),
                    'conversion_rate': (len(purchases) / len(sales_df) * 100),
                    'avg_page_value': purchases['PageValues'].mean(),
                    'avg_product_pages': purchases['ProductRelated'].mean(),
                    'avg_session_duration': purchases['ProductRelated_Duration'].mean(),
                    'avg_admin_duration': purchases['Administrative_Duration'].mean(),
                    'avg_info_duration': purchases['Informational_Duration'].mean(),
                    'bounce_rate': purchases['BounceRates'].mean(),
                    'exit_rate': purchases['ExitRates'].mean(),
                    'avg_special_day_value': purchases['SpecialDay'].mean()
                }
                
                sales_conditions[sales_period] = conditions
            
            period_conditions[period_name] = sales_conditions
            
        purchase_conditions[visitor_type] = period_conditions
    
    return purchase_conditions

def main():
    data_path = 'data/online_shoppers_intention.csv'
    
    if not os.path.exists(data_path):
        print(f"Error: Could not find the dataset at {data_path}")
        print("Please ensure the file 'online_shoppers_intention.csv' is in the data directory.")
        return
    
    try:
        # Load and preprocess data
        print("Loading and preprocessing data...")
        df = pd.read_csv(data_path)
        df_processed, month_encoder, visitor_encoder = preprocess_data(df)
        
        # Analyze customer segments with weekend/weekday split
        print("\nAnalyzing customer segments by time period and special days...")
        segment_analysis = analyze_customer_segments(df_processed, visitor_encoder)
        
        # Display results with clear separation
        print("\nCustomer Segment Analysis by Time Period and Special Days:")
        for time_period in ['Weekday', 'Weekend']:
            period_data = segment_analysis[segment_analysis['time_period'] == time_period]
            print(f"\n{time_period} Statistics:")
            print("=" * 50)
            
            for sales_period in period_data['SalesPeriod'].unique():
                sales_data = period_data[period_data['SalesPeriod'] == sales_period]
                print(f"\n  {sales_period}:")
                print("  " + "-" * 40)
                
                for _, row in sales_data.iterrows():
                    print(f"\n    Visitor Type: {row['VisitorType']}")
                    print(f"    Total Visits: {row['count']}")
                    print(f"    Successful Purchases: {row['sum']}")
                    print(f"    Conversion Rate: {row['conversion_rate']}%")
        
        # Analyze detailed purchase conditions
        print("\nAnalyzing detailed purchase conditions...")
        conditions = analyze_purchase_conditions(df_processed, visitor_encoder)
        
        print("\nDetailed Purchase Conditions by Customer Type, Time Period, and Special Days:")
        print("=" * 80)
        for visitor_type, period_data in conditions.items():
            print(f"\n{visitor_type} Customer Analysis:")
            
            for period, sales_data in period_data.items():
                print(f"\n  {period}:")
                print("  " + "=" * 30)
                
                for sales_period, metrics in sales_data.items():
                    print(f"\n    {sales_period}:")
                    print("    " + "-" * 25)
                    print(f"    Total Visits: {metrics['total_visits']}")
                    print(f"    Successful Purchases: {metrics['successful_purchases']}")
                    print(f"    Conversion Rate: {metrics['conversion_rate']:.2f}%")
                    print(f"    Average Page Value: ${metrics['avg_page_value']:.2f}")
                    print(f"    Average Product Pages: {metrics['avg_product_pages']:.1f}")
                    print(f"    Average Session Duration: {metrics['avg_session_duration']:.1f} seconds")
                    print(f"    Average Administrative Duration: {metrics['avg_admin_duration']:.1f} seconds")
                    print(f"    Average Informational Duration: {metrics['avg_info_duration']:.1f} seconds")
                    print(f"    Bounce Rate: {metrics['bounce_rate']:.3f}")
                    print(f"    Exit Rate: {metrics['exit_rate']:.3f}")
                    print(f"    Special Day Value: {metrics['avg_special_day_value']:.3f}")
            
    except Exception as e:
        print(f"An error occurred during execution: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()