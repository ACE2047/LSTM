import pandas as pd
import numpy as np
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

def load_and_preprocess_data(file_path):
    # Check if file exists
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Could not find the dataset at {file_path}")
    
    try:
        # Load the dataset
        data = pd.read_csv(file_path)
        
        # Handle categorical variables more carefully
        # Use Label Encoding for 'Month' as it has natural ordering
        le = LabelEncoder()
        data['Month'] = le.fit_transform(data['Month'])
        
        # One-hot encoding for other categorical variables
        categorical_columns = ['VisitorType', 'Weekend']
        data = pd.get_dummies(data, columns=categorical_columns)
        
        # Separate features and target
        X = data.drop('Revenue', axis=1)
        y = data['Revenue']
        
        # Scale the features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Reshape the data for LSTM (samples, timesteps, features)
        X_reshaped = X_scaled.reshape(X_scaled.shape[0], 1, X_scaled.shape[1])
        
        # Split the data with stratification to handle imbalanced classes
        X_train, X_test, y_train, y_test = train_test_split(
            X_reshaped, y, test_size=0.2, random_state=42, stratify=y
        )
        
        return X_train, X_test, y_train, y_test, X.shape[1]
    
    except Exception as e:
        print(f"Error during data preprocessing: {e}")
        raise

def create_enhanced_lstm_model(input_shape):
    try:
        model = Sequential([
            # First LSTM layer with increased units and return sequences
            LSTM(128, input_shape=input_shape, return_sequences=True),
            BatchNormalization(),
            Dropout(0.3),
            
            # Second LSTM layer
            LSTM(64, return_sequences=True),
            BatchNormalization(),
            Dropout(0.3),
            
            # Third LSTM layer
            LSTM(32),
            BatchNormalization(),
            Dropout(0.3),
            
            # Dense layers for classification
            Dense(32, activation='relu'),
            BatchNormalization(),
            Dropout(0.2),
            Dense(16, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        
        # Use a lower learning rate for better convergence
        optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
        
        model.compile(
            optimizer=optimizer,
            loss='binary_crossentropy',
            metrics=['accuracy', tf.keras.metrics.AUC(), tf.keras.metrics.Precision(), tf.keras.metrics.Recall()]
        )
        
        return model
    except Exception as e:
        print(f"Error creating LSTM model: {e}")
        raise

def plot_training_history(history):
    try:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
        
        # Plot accuracy
        ax1.plot(history.history['accuracy'])
        ax1.plot(history.history['val_accuracy'])
        ax1.set_title('Model Accuracy')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Accuracy')
        ax1.legend(['Train', 'Validation'])
        
        # Plot loss
        ax2.plot(history.history['loss'])
        ax2.plot(history.history['val_loss'])
        ax2.set_title('Model Loss')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Loss')
        ax2.legend(['Train', 'Validation'])
        
        plt.tight_layout()
        plt.show()
    except Exception as e:
        print(f"Error plotting training history: {e}")

def plot_confusion_matrix(y_true, y_pred):
    try:
        cm = confusion_matrix(y_true, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.show()
    except Exception as e:
        print(f"Error plotting confusion matrix: {e}")

def train_lstm_model(file_path):
    try:
        # Load and preprocess data
        X_train, X_test, y_train, y_test, n_features = load_and_preprocess_data(file_path)
        
        # Create model
        model = create_enhanced_lstm_model((1, n_features))
        
        # Define callbacks
        early_stopping = EarlyStopping(
            monitor='val_loss',
            patience=10,
            restore_best_weights=True
        )
        
        reduce_lr = ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.2,
            patience=5,
            min_lr=0.0001
        )
        
        # Train the model
        history = model.fit(
            X_train, y_train,
            epochs=100,
            batch_size=32,
            validation_split=0.2,
            callbacks=[early_stopping, reduce_lr],
            verbose=1
        )
        
        # Plot training history
        plot_training_history(history)
        
        # Evaluate the model
        print("\nModel Evaluation:")
        test_results = model.evaluate(X_test, y_test, verbose=0)
        metrics = ['Loss', 'Accuracy', 'AUC', 'Precision', 'Recall']
        for metric, value in zip(metrics, test_results):
            print(f'{metric}: {value:.4f}')
        
        # Make predictions
        y_pred = model.predict(X_test)
        y_pred_binary = (y_pred > 0.5).astype(int)
        
        # Plot confusion matrix
        plot_confusion_matrix(y_test, y_pred_binary)
        
        # Print classification report
        print('\nClassification Report:')
        print(classification_report(y_test, y_pred_binary))
        
        return model
    
    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("Please ensure the file exists in the specified location.")
    except Exception as e:
        print(f"An unexpected error occurred during model training: {e}")

def main():
    # Update the file path to use the data directory
    file_path = 'data/online_shoppers_intention.csv'
    
    try:
        train_lstm_model(file_path)
    except Exception as e:
        print(f"Failed to complete the LSTM modeling process: {e}")

if __name__ == '__main__':
    main()