import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import datetime as dt
from scipy import stats

class EnhancedSalesOptimizationAnalyzer:
    def __init__(self, df, competitor_data=None):
        self.df = df.copy()
        self.competitor_data = competitor_data
        self.scaler = StandardScaler()
        
    def calculate_roi_metrics(self, segment_data):
        """Calculate ROI and cost-benefit metrics"""
        # Assuming average customer acquisition cost (CAC) and customer lifetime value (CLV)
        avg_cac = 20  # Example CAC
        avg_clv = 150  # Example CLV
        
        metrics = {
            'conversion_rate': segment_data['Revenue'].mean() * 100,
            'avg_page_value': segment_data['PageValues'].mean(),
            'acquisition_cost': len(segment_data) * avg_cac,
            'potential_revenue': segment_data['Revenue'].sum() * avg_clv,
            'roi': (segment_data['Revenue'].sum() * avg_clv - len(segment_data) * avg_cac) / (len(segment_data) * avg_cac) * 100
        }
        
        return metrics

    def analyze_detailed_metrics(self):
        """Enhanced analysis with detailed metrics for each category"""
        metrics = {
            'visitor_segments': {},
            'time_periods': {},
            'traffic_sources': {}
        }
        
        # Visitor segment detailed metrics
        for visitor_type in self.df['VisitorType'].unique():
            segment = self.df[self.df['VisitorType'] == visitor_type]
            metrics['visitor_segments'][visitor_type] = {
                'basic_metrics': {
                    'total_visits': len(segment),
                    'conversion_rate': segment['Revenue'].mean() * 100,
                    'avg_duration': segment['ProductRelated_Duration'].mean(),
                    'pages_per_visit': segment['ProductRelated'].mean()
                },
                'engagement_metrics': {
                    'bounce_rate': segment['BounceRates'].mean(),
                    'exit_rate': segment['ExitRates'].mean(),
                    'page_value': segment['PageValues'].mean(),
                    'admin_duration': segment['Administrative_Duration'].mean(),
                    'info_duration': segment['Informational_Duration'].mean()
                },
                'roi_metrics': self.calculate_roi_metrics(segment)
            }
        
        # Time period analysis
        for weekend in [0, 1]:
            period = self.df[self.df['Weekend'] == weekend]
            metrics['time_periods'][f'{"Weekend" if weekend else "Weekday"}'] = {
                'traffic_distribution': len(period) / len(self.df) * 100,
                'conversion_rate': period['Revenue'].mean() * 100,
                'revenue_contribution': period['Revenue'].sum() / self.df['Revenue'].sum() * 100,
                'roi_metrics': self.calculate_roi_metrics(period)
            }
        
        return metrics

    def analyze_seasonal_trends(self):
        """Detailed seasonal trend analysis"""
        seasonal_metrics = {
            'monthly_trends': {},
            'special_day_impact': {},
            'year_over_year': {}  # If data spans multiple years
        }
        
        # Ensure Month column is numeric
        self.df['Month'] = pd.to_numeric(self.df['Month'], errors='coerce')
        
        # Monthly conversion trends
        monthly_data = self.df.groupby('Month').agg({
            'Revenue': ['count', 'mean', 'sum'],
            'PageValues': 'mean',
            'ProductRelated': 'mean',
            'BounceRates': 'mean'
        })
        
        # Calculate seasonal indices
        monthly_data['seasonal_index'] = monthly_data[('Revenue', 'mean')] / monthly_data[('Revenue', 'mean')].mean()
        
        # Identify peak and low seasons (ensure months are integers)
        peak_months = monthly_data[monthly_data['seasonal_index'] > 1].index.astype(int)
        low_months = monthly_data[monthly_data['seasonal_index'] < 1].index.astype(int)
        
        seasonal_metrics['monthly_trends'] = {
            'peak_months': peak_months.tolist(),
            'low_months': low_months.tolist(),
            'seasonal_variation': monthly_data['seasonal_index'].std(),
            'month_by_month': monthly_data.to_dict()
        }
        
        # Special day impact analysis
        special_day_impact = self.df.groupby('SpecialDay').agg({
            'Revenue': ['count', 'mean'],
            'PageValues': 'mean',
            'ProductRelated': 'mean'
        })
        
        seasonal_metrics['special_day_impact'] = special_day_impact.to_dict()
        
        return seasonal_metrics

    def benchmark_against_competitors(self, competitor_metrics=None):
        """Compare performance against industry benchmarks"""
        # Calculate our metrics first
        our_metrics = {
            'conversion_rate': self.df['Revenue'].mean() * 100,
            'bounce_rate': self.df['BounceRates'].mean() * 100,
            'session_duration': self.df['ProductRelated_Duration'].mean(),
            'pages_per_session': self.df['ProductRelated'].mean(),
            'new_visitor_ratio': len(self.df[self.df['VisitorType'] == 'New_Visitor']) / len(self.df) * 100
        }
        
        # Example industry benchmarks (would be replaced with real competitor data)
        industry_benchmarks = {
            'conversion_rate': 2.86,
            'bounce_rate': 45.68,
            'session_duration': 180,
            'pages_per_session': 3.3,
            'new_visitor_ratio': 58.23
        }
        
        if competitor_metrics:
            industry_benchmarks.update(competitor_metrics)
        
        # Compare and calculate relative performance
        benchmarking = {
            metric: {
                'our_value': our_metrics[metric],
                'industry_avg': industry_benchmarks[metric],
                'relative_performance': (our_metrics[metric] / industry_benchmarks[metric] - 1) * 100
            }
            for metric in industry_benchmarks.keys()
        }
        
        return benchmarking

    def generate_enhanced_recommendations(self):
        """Generate comprehensive recommendations with cost-benefit analysis"""
        detailed_metrics = self.analyze_detailed_metrics()
        seasonal_trends = self.analyze_seasonal_trends()
        competitor_benchmark = self.benchmark_against_competitors()
        
        recommendations = {
            'immediate_actions': [],
            'strategic_initiatives': [],
            'seasonal_preparations': [],
            'competitive_responses': []
        }
        
        # Immediate action recommendations
        for visitor_type, metrics in detailed_metrics['visitor_segments'].items():
            if metrics['roi_metrics']['roi'] < 50:  # Example threshold
                recommendations['immediate_actions'].append({
                    'focus': f'Improve {visitor_type} ROI',
                    'finding': f"Current ROI: {metrics['roi_metrics']['roi']:.1f}%",
                    'action': "Optimize acquisition channels and landing pages",
                    'cost_estimate': f"${metrics['roi_metrics']['acquisition_cost']:.2f}",
                    'potential_benefit': f"${metrics['roi_metrics']['potential_revenue']:.2f}",
                    'priority': 'High' if metrics['roi_metrics']['roi'] < 0 else 'Medium'
                })
        
        # Strategic initiatives based on seasonal trends
        for month in seasonal_trends['monthly_trends']['low_months']:
            # Ensure month is an integer
            month_int = int(month)
            recommendations['seasonal_preparations'].append({
                'focus': f'Month {month_int} Optimization',
                'finding': "Below average performance in this month",
                'action': "Prepare seasonal promotion strategy",
                'timing': f"Start preparation {((month_int - 1) % 12) or 12}",
                'expected_lift': f"{abs(seasonal_trends['monthly_trends']['seasonal_variation'] * 100):.1f}%"
            })
        
        # Competitive response recommendations
        for metric, benchmark in competitor_benchmark.items():
            if benchmark['relative_performance'] < -10:  # We're 10% worse than industry
                recommendations['competitive_responses'].append({
                    'focus': f'Improve {metric}',
                    'finding': f"Currently {abs(benchmark['relative_performance']):.1f}% below industry average",
                    'action': "Implement industry best practices",
                    'target_improvement': f"{abs(benchmark['relative_performance']):.1f}%",
                    'priority': 'High' if benchmark['relative_performance'] < -20 else 'Medium'
                })
        
        return recommendations

def main():
    try:
        # Load data
        df = pd.read_csv('data/online_shoppers_intention.csv')
        
        # Initialize enhanced analyzer
        analyzer = EnhancedSalesOptimizationAnalyzer(df)
        
        # Generate comprehensive recommendations
        recommendations = analyzer.generate_enhanced_recommendations()
        detailed_metrics = analyzer.analyze_detailed_metrics()
        seasonal_trends = analyzer.analyze_seasonal_trends()
        competitor_benchmark = analyzer.benchmark_against_competitors()
        
        # Display comprehensive analysis
        print("\nE-commerce Performance Optimization Analysis")
        print("=" * 50)
        
        # 1. Key Metrics Overview
        print("\n1. Key Performance Metrics:")
        print("-" * 40)
        for segment, metrics in detailed_metrics['visitor_segments'].items():
            print(f"\n{segment} Segment:")
            print(f"Conversion Rate: {metrics['basic_metrics']['conversion_rate']:.2f}%")
            print(f"ROI: {metrics['roi_metrics']['roi']:.2f}%")
            print(f"Potential Revenue: ${metrics['roi_metrics']['potential_revenue']:.2f}")
        
        # 2. Seasonal Trends
        print("\n2. Seasonal Analysis:")
        print("-" * 40)
        print(f"Peak Months: {', '.join(map(str, seasonal_trends['monthly_trends']['peak_months']))}")
        print(f"Low Months: {', '.join(map(str, seasonal_trends['monthly_trends']['low_months']))}")
        print(f"Seasonal Variation: {seasonal_trends['monthly_trends']['seasonal_variation']:.2f}")
        
        # 3. Competitive Benchmarking
        print("\n3. Competitive Position:")
        print("-" * 40)
        for metric, data in competitor_benchmark.items():
            print(f"\n{metric}:")
            print(f"Our Performance: {data['our_value']:.2f}")
            print(f"Industry Average: {data['industry_avg']:.2f}")
            print(f"Relative Position: {data['relative_performance']:+.1f}%")
        
        # 4. Recommendations
        print("\n4. Strategic Recommendations:")
        print("-" * 40)
        for category, recs in recommendations.items():
            if recs:  # Only print categories with recommendations
                print(f"\n{category.replace('_', ' ').title()}:")
                for rec in recs:
                    print(f"\nFocus Area: {rec['focus']}")
                    print(f"Finding: {rec['finding']}")
                    print(f"Recommended Action: {rec['action']}")
                    if 'cost_estimate' in rec:
                        print(f"Estimated Cost: {rec['cost_estimate']}")
                        print(f"Potential Benefit: {rec['potential_benefit']}")
                    if 'priority' in rec:
                        print(f"Priority: {rec['priority']}")
                    
    except Exception as e:
        print(f"An error occurred: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()