import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
import os

def load_and_analyze_data(file_path):
    """Load and perform detailed analysis of the shopping dataset."""
    # Check if file exists
    if not os.path.exists(file_path):
        print(f"Error: Could not find the dataset at {file_path}")
        raise FileNotFoundError(f"Dataset not found at {file_path}")
    
    # Load the data
    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        print(f"Error loading data: {e}")
        raise
    
    # Basic information about the dataset
    print("\n=== Dataset Overview ===")
    print("\nDataset Shape:", df.shape)
    print("\nColumns:", df.columns.tolist())
    print("\nData Types:\n", df.dtypes)
    
    # Check for missing values
    print("\n=== Missing Values ===")
    print(df.isnull().sum())
    
    # Basic statistics
    print("\n=== Numerical Features Statistics ===")
    print(df.describe())
    
    return df

def plot_data_distributions(df):
    """Create visualizations for data distributions."""
    # Set up the style
    plt.style.use('ggplot')
    
    # Numerical features distribution
    numerical_cols = df.select_dtypes(include=['float64', 'int64']).columns
    n_cols = len(numerical_cols)
    
    # Create subplots for numerical features
    fig, axes = plt.subplots(n_cols // 3 + 1, 3, figsize=(15, 5 * (n_cols // 3 + 1)))
    axes = axes.ravel()
    
    for idx, col in enumerate(numerical_cols):
        sns.histplot(data=df, x=col, ax=axes[idx], bins=30)
        axes[idx].set_title(f'Distribution of {col}')
    
    plt.tight_layout()
    plt.show()
    
    # Categorical features analysis
    categorical_cols = ['Revenue', 'Weekend', 'Month', 'VisitorType']
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    axes = axes.ravel()
    
    for idx, col in enumerate(categorical_cols):
        sns.countplot(data=df, x=col, ax=axes[idx])
        axes[idx].set_title(f'Distribution of {col}')
        if col == 'Month':
            axes[idx].tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    plt.show()

def plot_correlation_matrix(df):
    """Create and plot correlation matrix."""
    # Select numerical columns
    numerical_df = df.select_dtypes(include=['float64', 'int64'])
    
    # Calculate correlation matrix
    correlation_matrix = numerical_df.corr()
    
    # Plot correlation matrix
    plt.figure(figsize=(12, 8))
    sns.heatmap(correlation_matrix, 
                annot=True, 
                cmap='coolwarm', 
                center=0,
                fmt='.2f')
    plt.title('Correlation Matrix of Numerical Features')
    plt.tight_layout()
    plt.show()

def analyze_revenue_patterns(df):
    """Analyze patterns related to Revenue."""
    # Revenue by Month
    plt.figure(figsize=(12, 5))
    sns.barplot(data=df, x='Month', y='Revenue')
    plt.title('Revenue Rate by Month')
    plt.xticks(rotation=45)
    plt.show()
    
    # Revenue by VisitorType
    plt.figure(figsize=(10, 5))
    sns.barplot(data=df, x='VisitorType', y='Revenue')
    plt.title('Revenue Rate by Visitor Type')
    plt.show()
    
    # Revenue by Weekend/Weekday
    plt.figure(figsize=(8, 5))
    sns.barplot(data=df, x='Weekend', y='Revenue')
    plt.title('Revenue Rate by Weekend vs Weekday')
    plt.show()

def generate_summary_report(df):
    """Generate a summary report of key findings."""
    print("\n=== Summary Report ===")
    
    # Class balance
    print("\nClass Balance (Revenue):")
    print(df['Revenue'].value_counts(normalize=True))
    
    # Visitor type distribution
    print("\nVisitor Type Distribution:")
    print(df['VisitorType'].value_counts(normalize=True))
    
    # Weekend vs Weekday
    print("\nWeekend vs Weekday Distribution:")
    print(df['Weekend'].value_counts(normalize=True))
    
    # Monthly distribution
    print("\nMonthly Distribution:")
    print(df['Month'].value_counts(normalize=True).sort_index())
    
    # Average page values and bounce rates
    print("\nKey Metrics:")
    print(f"Average Page Values: {df['PageValues'].mean():.2f}")
    print(f"Average Bounce Rate: {df['BounceRates'].mean():.2f}")
    print(f"Average Exit Rate: {df['ExitRates'].mean():.2f}")

def main():
    # Define the file path
    file_path = 'data/online_shoppers_intention.csv'
    
    try:
        # Load and analyze data
        df = load_and_analyze_data(file_path)
        
        # Generate visualizations
        plot_data_distributions(df)
        plot_correlation_matrix(df)
        analyze_revenue_patterns(df)
        
        # Generate summary report
        generate_summary_report(df)
    except FileNotFoundError as e:
        print(f"Error: {e}")
        print("Please ensure the file 'online_shoppers_intention.csv' is in the data directory.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == '__main__':
    main()